Java
javac, -m, market_price.txt, -p, price_list.txt
