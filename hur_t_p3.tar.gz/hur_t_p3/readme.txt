Java
Code Problems: The backtracking files often do not have the correct included nodes. However, they should have the correct max Profit.
Honesty Statement: I did not cheat/plagiarize for this assignment.
